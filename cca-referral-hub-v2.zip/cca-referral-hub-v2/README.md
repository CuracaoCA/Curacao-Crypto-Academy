# Curaçao Crypto Academy — Rewards & Referral Hub (v2)

Includes:
- Your logo in the hero
- Favicon + OG banner
- Real social links (Facebook) + placeholders for Instagram/YouTube/TikTok
- Invented, safe bonus text for each referral card

Deploy via GitHub Pages, Netlify (drag & drop), or Vercel.
